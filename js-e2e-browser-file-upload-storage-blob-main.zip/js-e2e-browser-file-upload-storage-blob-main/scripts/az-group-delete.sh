# https://docs.microsoft.com/en-us/cli/azure/group?view=azure-cli-latest#az_group_delete
az group delete --name
                --no-wait
                --subscription YOUR-SUBSCRIPTION-ID
                --yes