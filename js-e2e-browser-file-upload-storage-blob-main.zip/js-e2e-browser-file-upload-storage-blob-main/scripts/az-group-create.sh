# https://docs.microsoft.com/cli/azure/group?view=azure-cli-latest#az_group_create
az group create --location westus
                --name rg-YOUR-NAME
                --subscription YOUR-SUBSCRIPTION-ID